summary(ca.jo(Canada, type = "trace",
              ecdet = "trend", K = 3,
              spec = "transitory"))
summary(ca.jo(Canada, type = "trace",
              ecdet = "trend", K = 2,
              spec = "transitory"))
